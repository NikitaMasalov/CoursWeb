from django.apps import AppConfig


class ValidationConfig(AppConfig):
    name = 'validation'
